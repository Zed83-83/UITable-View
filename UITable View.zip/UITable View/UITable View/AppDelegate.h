//
//  AppDelegate.h
//  UITable View
//
//  Created by Zed Zezhenko on 28.08.2018.
//  Copyright © 2018 Zed Zezhenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

